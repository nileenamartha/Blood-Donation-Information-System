<?php
 session_start();
	  $lid=$_SESSION["l_id"];
 if(!isset($_SESSION['l_id']))
	  {
      header("Location:../index.php"); 
	  ?>
      <!DOCTYPE html>
    <html>
    <head>
    <link rel="stylesheet" href="style.css">
    </head>
    <body>
    <div id="navBar">
    <h2>LifeStream</h2>
    <ul>
      <li><a href="../logout/logout.php">Logout</a></li>
      <li><a href="#home">Contact</a></li>
      <li><a href="../why_donate_blood/wdb.php">Why Donate Blood</a></li>
      <li><a href="../index.php">Home</a></li>
    </ul>
    </div>
      <?php
	  }
?> 
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div id="navBar">
<h2>LifeStream</h2>
<ul>
  <li><a href="../logout/logout.php">Logout</a></li>
  <li><a href="login.php">MyProfile</a></li>
  <li><a href="../index.php">Home</a></li>
</ul>
</div>
<?php
$conn=mysqli_connect("localhost","root","","blood_info");
$sql="select name from donor_register where l_id='$lid'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	while($data=mysqli_fetch_array($result))
	{
?>
<h3 style="color:#c02729; width: 200px; height: 6.889;"> Welcome <?php echo $data["name"] ?> </h3>
<?php
	}
}
?>
<section class="options" id="op">
<div id="box">
<div id="edit">
<button onClick="window.location.href='../donor_edit_profile/edit.php'">Edit Profile</button>
</div>
<div id="Notify">
<button onClick="window.location.href='../donor_notification/notification.php'">Notification</button>
</div>
<div id="de">
<button onClick="window.location.href='../confirm/confirm_deactivate_donor.php'">Deactivate</button>
</div>
</div>
</section>
</body>
</html>